# AMC-IoT
AMC-IoT: Automatic Modulation Classification Using Efficient Convolutional Neural Networks for Low Powered IoT Devices

cite as:
Usman, Muhammad, and Jeong-A. Lee. "AMC-IoT: Automatic Modulation Classification Using Efficient Convolutional Neural Networks for Low Powered IoT Devices." 2020 International Conference on Information and Communication Technology Convergence (ICTC). IEEE, 2020.

@inproceedings{usman2020amc,
  title={AMC-IoT: Automatic Modulation Classification Using Efficient Convolutional Neural Networks for Low Powered IoT Devices},
  author={Usman, Muhammad and Lee, Jeong-A},
  booktitle={2020 International Conference on Information and Communication Technology Convergence (ICTC)},
  pages={288--293},
  year={2020},
  organization={IEEE}
}
